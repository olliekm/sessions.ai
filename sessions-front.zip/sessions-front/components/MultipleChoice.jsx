import React, { useState } from "react";

function MultipleChoice({ answerContent, correct, question, onChange }) {
  const [selectedOption, setSelectedOption] = useState(null);

  const handleOptionChange = (e) => {
    const selectedValue = parseInt(e.target.value, 10);
    setSelectedOption(selectedValue);
    // Call the onChange function passed from the parent to send the selected value
    onChange(selectedValue);
  };

  return (
    <div className="flex flex-col space-y-2 text-xl relative p-8">
      {/* <div className="absolute bottom-0 right-0 p-2 ">
        <button className="p-3 text-indigo-200 border-[1px] border-white/30 text-sm rounded-xl font-semibold bg-gradient-to-r from-slate-900 via-indigo-900 to-slate-900">
          AI answer
        </button>
      </div> */}
      <p className="text-2xl font-semibold">{question}</p>

      {answerContent.map((mcq, jdx) => (
        <div key={jdx} className="space-x-2">
          <input
            type="radio"
            id={jdx}
            name={"mcq"}
            value={jdx}
            checked={selectedOption === jdx}
            onChange={handleOptionChange} // Trigger when option is selected
          />
          <label htmlFor={jdx}>{mcq}</label>
        </div>
      ))}
    </div>
  );
}

export default MultipleChoice;
