import React from "react";

function Definitions({ question, aiAnswer }) {
  return <div>Definitions</div>;
}

export default Definitions;
