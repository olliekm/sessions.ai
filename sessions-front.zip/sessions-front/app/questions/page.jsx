"use client";
import React, { useState, useEffect } from "react";
import MultipleChoice from "@/components/MultipleChoice";
import LongAnswer from "@/components/LongAnswer";
import useStore from "@/store/store";
function page() {
  const [hasCompleted, setHasCompleted] = useState(false);
  const [formData, setFormData] = useState({});
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const allQuestions = useStore((state) => state.questions);

  const handleInputChange = (idx, value) => {
    if (formData[idx] == sampleRes["Vector Equations"][idx].correct) {
      setCorrectAnswers(correctAnswers + 1);
    }
    setFormData((prevData) => ({
      ...prevData,
      [idx]: value,
    }));
  };

  const handleSubmit = (e) => {
    console.log("whweqw");
    e.preventDefault();
    console.log("Collected Form Data: ", formData);
    setHasCompleted(true);
  };

  return (
    <div className="space-y-4">
      <div
        className={`fixed  ${
          hasCompleted ? "translate-y-0" : "translate-y-full"
        } top-0 left-0 h-screen w-full bg-violet-500 z-20 duration-200 ease-in flex flex-col justify-center items-center`}
      >
        <div className="flex flex-col text-center">
          <h1 className="text-4xl">🎉</h1>
          <h1 className="text-4xl font-semibold">Amazing job!</h1>
          You got {correctAnswers} questions right
        </div>
      </div>
      <div className="p-8">
        <h1 className="text-5xl font-semibold text-violet-500">
          Question time ✏️
        </h1>
        <p className="text-xl">
          Based on your study habits, we compiled these questions:
        </p>
      </div>
      <div className="w-full h-[1px] bg-violet-500"></div>
      <form onSubmit={handleSubmit}>
        <div className="flex flex-col space-y-4 divide-y-[1px] divide-violet-500">
          {Object.keys(allQuestions).map((q, idx) => (
            <div key={idx + allQuestions[q].question}>
              {allQuestions[q].qType == 1 ? (
                <LongAnswer
                  key={idx}
                  question={allQuestions[q].question}
                  answer={allQuestions[q].answer}
                />
              ) : (
                <MultipleChoice
                  key={idx}
                  question={allQuestions[q].question}
                  answerContent={allQuestions[q].answer.content}
                  correct={allQuestions[q].answer.correct}
                  onChange={(value) => handleInputChange(idx, value)} // Pass the selected answer back
                />
              )}
            </div>
          ))}
        </div>
        <button
          type="submit"
          className="fixed bottom-0 left-0 h-16 bg-violet-600 font-semibold w-full hover:bg-violet-500 duration-100"
        >
          Submit
        </button>
      </form>
    </div>
  );
}

export default page;
